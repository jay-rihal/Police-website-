<?php
// Start the session
session_start();
?>
<html>
<body>
<main>
  <h1>Change Password </h1>
  
  <form  method="POST">
      Old Password: <input type="password" name="oldpassword"><br/>
      New Password: <input type="password" name="newpassword"><br/>
      Confirm New Password: <input type="password" name="confirmnewpassword" ><br/>
      <input type="submit" value="Change Password">
  </form>

  <style>

div{margin-top: 50px;
    }

    html, body {
    display: flex;
    justify-content: center;
    font-family: Roboto, Arial, sans-serif;
    font-size: 15px;
    height: 100px;
    }
    form {
    border: 0px solid #f1f1f1;
    }
    input[type=password] {
    width: 100%;
    padding: 16px 8px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
    height: 50px;
    }
    input[type=submit] {
    background-color: blue;
    color: white;
    padding: 14px 0;
    margin: 10px 0;
    border: none;
    cursor: grabbing;
    width: 100%;
    }
    h1 {
    text-align:center;
    font-size:32;
    }
    button:hover {
    opacity: 0.8;
    }
    .formcontainer {
    text-align: left;
    margin: 24px 50px 20px;
    }
    .container {
    padding: 16px 0;
    text-align:left;
    }
    span.psw {
    float: right;
    padding-top: 100;
    padding-right: 30px;
    }

  </style> 


  <?php
        error_reporting(E_ALL);
        ini_set('display_errors', 1);  

         $servername = "***";
        $username = "***";
        $password = "***";
        $dbname = "***";   


        //Check whether variable is set
        if (isset($_POST['oldpassword'])) 
        {
        
          // Check connection
        $conn = mysqli_connect($servername, $username, $password, $dbname);
          if(!$conn) {
            die ("Connection failed");
        }
        // set variable  
        $oldpassword = $_POST['oldpassword'];
        $newpassword = $_POST['newpassword'];
        $confirmnewpassword = $_POST['confirmnewpassword'];
       // $username
 
        {
          $sql = "SELECT * from logindetails WHERE userid ='".$_SESSION['userid']."'";
          $result = $conn->query($sql);

          if ($result->num_rows > 0) {

          // output data of each row

          while($row = $result->fetch_assoc()) {

          //save database password as variable

          $olddbpassword = $row["password"];
        }
      }
    }

        // and old password in db == password typed in
        if ($newpassword == $confirmnewpassword AND $oldpassword == $olddbpassword)
       {
        // $sql = "SELECT password from logindetails WHERE userid ='".$_SESSION['userid']."'";

        $sql = "UPDATE logindetails SET password = '$newpassword' WHERE userid = '".$_SESSION['userid']."' AND password = '$oldpassword'" ; 
        $result = mysqli_query($conn, $sql);
          echo "Password successfully changed";
       } 
      else
       {
         echo 'New passwords do not match or old password entered incorrectly!';
       }
                 
       
       mysqli_close($conn);
   
    }
      ?> 
</main>
<div2 style="position:fixed; right:5; top:5; font-family: Roboto, Arial, sans-serif;
      font-size: 20px;">
<footer><a href="menu.php">Homepage</a></footer>
<footer><a href="login.php">Log out</a></footer>
  </div2>
</body>
</html>