<?php
// Start the session
session_start();
?>

<html>
<body>
  <h1>Add Policeman Account </h1>

  <form method="post">
        Username: <input name="username" type="text" Required><br/>
        Password: <input name="password" type="text" Required><br/>
        <br>Would you like to create an Admin Or Police officer account? <br/> 
        <input type="radio" id="radio" name="type" value="1">
        <label for="type">Admin
        <input type="radio" id="radio2" name="type" value="0">
        User </label>
       <br> <input type="submit" value = "Create"> <br/>
    </form>

    <style>

    html, body {
    display: flex;
    justify-content: center;
    font-family: Roboto, Arial, sans-serif;
    font-size: 15px;
    height: 100px;
    }
    form {
    margin-top: 90px;
    border: 0px solid #f1f1f1;
    }
    input[type=password], input[type=text] {
    width: 100%;
    padding: 16px 8px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
    height: 50px;
    }
    input[type=submit] {
    background-color: blue;
    color: white;
    padding: 14px 0;
    margin: 10px 0;
    border: none;
    cursor: grabbing;
    width: 100%;
    }
    h1 {
    text-align:center;
    font-size:32;
    }
    button:hover {
    opacity: 0.8;
    }
    .formcontainer {
    text-align: left;
    margin: 24px 50px 20px;
    }
    .container {
    padding: 16px 0;
    text-align:left;
    }
    span.psw {
    float: right;
    padding-top: 100;
    padding-right: 30px;
    }
</style>

    <?php
        error_reporting(E_ALL);
        ini_set('display_errors', 1);
        
         $servername = "***";
        $username = "***";
        $password = "***";
        $dbname = "***"; 

    
        if (isset($_POST['username']) && isset($_POST['password'])) 
        {
         $conn = mysqli_connect($servername, $username, $password, $dbname);
         if(!$conn) {
             die ("Connection failed");
          }

          $username = $_POST['username'];
          $password = $_POST['password'];
          $type = $_POST['type'];
        
        { 
        $sql = "INSERT INTO logindetails SET username = '$username', password = '$password', Admin = '$type'";

          if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
         } 
         else {
            echo "record cannot be created";
          }
        
        }  
        mysqli_close($conn);
        
    }
    ?>
</body>

<footer><a href="menu.php">Go Back</a></footer></div>
<footer><a href="login.php">Log out</a></footer></div>
</html>