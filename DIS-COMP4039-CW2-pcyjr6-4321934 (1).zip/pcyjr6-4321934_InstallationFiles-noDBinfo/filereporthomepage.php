##got button from here https://cssbuttons.io/detail/alexroumi/shy-sloth-91##

<?php
// Start the session
session_start();
?>

<html>

<form action = "incidentreport2.php">
<button> File a new report
</form> </button>
<form action ="showreport.php">
<button> Edit or delete an existing report </br>
</button> </form>

<style>
    body {
  height: 100px;
  background-color: white;
  background-image: url(https://pbs.twimg.com/profile_images/1410560774687313923/N8oxbEC0_400x400.jpg);
  background-repeat: repeat-y;
}
</style>
<style>


.text-center {
  text-align: center;
}


button {
    display: block;
    width: 500px;
}

button {
    padding: 20px 70px;
    border: unset;
    border-radius: 40px;
    color: #212121;
    z-index: 1;
    background: #e8e8e8;
    position: relative;
    font-weight: 1000;
    font-size: 20px;
    -webkit-box-shadow: 4px 8px 19px -3px rgba(0,0,0,0.27);
    box-shadow: 4px 8px 19px -3px rgba(0,0,0,0.27);
    transition: all 250ms;
    overflow: hidden;
    margin: auto;
    margin-top: 200px;
   }
   
   button::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    width: 0;
    border-radius: 15px;
    background-color: #212121;
    z-index: -1;
    -webkit-box-shadow: 4px 8px 19px -3px rgba(0,0,0,0.27);
    box-shadow: 4px 8px 19px -3px rgba(0,0,0,0.27);
    transition: all 250ms
   }
   
   button:hover {
    color: #e8e8e8;
   }
   
   button:hover::before {
    width: 100%;
   }


</style>

<div style="position:fixed; right:5; top:5; font-family: Roboto, Arial, sans-serif;
      font-size: 20px;">
<footer><a href="menu.php">Back</a></footer>
<footer><a href="menu.php">Homepage</a></footer>
</div>
   </html>