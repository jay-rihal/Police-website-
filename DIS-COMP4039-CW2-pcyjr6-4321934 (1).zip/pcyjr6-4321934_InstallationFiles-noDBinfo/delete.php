<?php
// Start the session
//
session_start();
?>
<html>
<body>

<h3>Update Data</h3>

<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);  

 $servername = "***";
        $username = "***";
        $password = "***";
        $dbname = "***"; 

$conn = mysqli_connect($servername, $username, $password, $dbname);

$id = $_GET['id'];

    $sql = "DELETE FROM Fines where Incident_ID = '$id'";
    $conn->query($sql);
    
    $sql = "DELETE FROM Incident where Incident_ID = '$id'";

    $result = mysqli_query($conn, $sql);
    if ($conn->query($sql) === TRUE) {
        echo "Record deleted";
     } 
     else {
        echo "Error: " . $sql . "<br>" . $conn->error;
      }

      mysqli_close($conn); // Close connection
      header("location:showreport.php"); // redirects to all records page
      exit;
      
    

?>

</main>
<footer><a href="showreport.php">Back</a></footer>
<footer><a href="menu.php">Homepage</a></footer>
<footer><a href="login.php">Log out</a></footer>
</body>
</html>


