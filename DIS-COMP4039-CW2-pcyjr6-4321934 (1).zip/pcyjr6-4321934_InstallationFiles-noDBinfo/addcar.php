<?php
// Start the session
session_start();
?>


<html>
<body>
<main>
   
<h1>People Search</h1>


  <br><form  method="POST">
      Search for the person Licence Number: <input type="text" name="licencenumber" Required><br/>
      <input type="submit" value="Submit"></br>
  </form>
  


  <?php


        error_reporting(E_ALL);
        ini_set('display_errors', 1);  

         $servername = "***";
        $username = "***";
        $password = "***";
        $dbname = "***";  
          

        if (isset($_POST['licencenumber']))
        {
          
            // Check connection
            $conn = mysqli_connect($servername, $username, $password, $dbname);
            if (!$conn)
            {
                die("Connection failed");
            }
            // set variable
            $licencenumber = $_POST['licencenumber'];
            // construct the SELECT query
            $sql = "SELECT * FROM People WHERE People_licence LIKE '$licencenumber'";


            // send query to DB
            $result = mysqli_query($conn, $sql);

            // check that something has been returned
            if (mysqli_num_rows($result) > 0)
            {
        
                while ($row = mysqli_fetch_assoc($result))
                {
                   $_SESSION['PeopleID']=$row['People_ID'];
                    echo $row["People_name"] . " - " . $row["People_address"] . " - " . $row["People_licence"] . "<br/>";
                    echo "<br>";
                }
            }
        
            else
            // if query result is empty
            
            {
                echo "Nothing found!";
            }
        
            mysqli_close($conn);
  }
  ?>

<body>
  <br><form method="POST" action="addcarexisting.php">
    <input type="submit" value = "Correct person"/>

  </form>
</body>
<body>
    <form method="POST" action="addcarnew.php">
    <input type="submit" value = "Enter New Person and Vehicle"/>
  </form>
</body>
<style>

      html, body {
      display: flex;
      justify-content: center;
      font-family: Roboto, Arial, sans-serif;
      font-size: 15px;
      height: 100px;
      }
      input[type=submit] {
      background-color: blue;
      color: white;
      width: 100%;
      padding: 16px 8px;
      margin: 8px 0;
      display: inline-block;
      border: 1px solid #ccc;
      box-sizing: border-box;
      height: 50px;
      }
      input[type=text] {
      background-color: white;
      color: black;
      width: 100%;
      padding: 16px 8px;
      margin: 8px 0;
      display: inline-block;
      border: 1px solid #ccc;
      box-sizing: border-box;
      height: 50px;
      }
      h1 {
      text-align:center;
      font-size:32;
      }
      input:hover {
      opacity: 0.8;
      }

    </style>


</main>
<div style="position:absolute; right:0;">
<a href="menu.php">Back</a><br>
<a href="menu.php">Homepage</a><br>
</div>
</body>
</html>