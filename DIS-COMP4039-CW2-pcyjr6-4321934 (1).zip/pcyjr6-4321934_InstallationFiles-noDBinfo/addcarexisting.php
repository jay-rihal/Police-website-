<?php
// Start the session
session_start();
?>


<html>
<body>
<main>
   
<h1>Add Car</h1>


<form  method="POST">
      Vehicle Licence: <input type="text" name="carREG" placeholder="Vehicle licence" Required><br/>
      Make and Model: <input type="text" name="carmakemodel" placeholder="Car make and model" Required><br/>
      Colour: <input type="text" name="carcolour"placeholder ="Car colour" Required><br/>
      <input type="submit" value="Submit">
  </form>

  <style>
      div{margin-top: 50px;
      }

      html, body {
      display: flex;
      justify-content: center;
      font-family: Roboto, Arial, sans-serif;
      font-size: 15px;
      height: 100px;
      }
      form {
      border: 0px solid #f1f1f1;
      }
      input[type=text] {
      width: 100%;
      padding: 16px 8px;
      margin: 8px 0;
      display: inline-block;
      border: 1px solid #ccc;
      box-sizing: border-box;
      height: 50px;
      }
      input[type=submit] {
      background-color: blue;
      color: white;
      padding: 14px 0;
      margin: 10px 0;
      border: none;
      cursor: grabbing;
      width: 100%;
      }
      h1 {
      text-align:center;
      font-size:32;
      }
      button:hover {
      opacity: 0.8;
      }
      .formcontainer {
      text-align: left;
      margin: 24px 50px 20px;
      }
      .container {
      padding: 16px 0;
      text-align:left;
      }
      span.psw {
      float: right;
      padding-top: 100;
      padding-right: 30px;
      }

    </style>  

  <?php

error_reporting(E_ALL);
ini_set('display_errors', 1);  

 $servername = "***";
        $username = "***";
        $password = "***";
        $dbname = "***"; 

$conn = mysqli_connect($servername, $username, $password, $dbname);
if(!$conn) {
  die ("Connection failed");
}
if (isset($_POST['carREG'])) 
{
$regplate = $_POST['carREG'];
$car_colour = $_POST['carcolour'];
$carmake = $_POST['carmakemodel'];

  $sql = "INSERT INTO Vehicle SET Vehicle_licence='$regplate',Vehicle_colour='$car_colour',Vehicle_type='$carmake'";
  
  if ($conn->query($sql) === TRUE) {
    echo "";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }

$PeopleID = $_SESSION['PeopleID'];

   $sql = "SELECT * from Vehicle WHERE Vehicle_licence = '$regplate'";
   $result = mysqli_query($conn, $sql);
   if (mysqli_num_rows($result) > 0)
   {
        while($row = mysqli_fetch_assoc($result)) 
        {
          $VehicleID = $row["Vehicle_ID"];}}
     
    

  $sql = "INSERT into Ownership SET People_ID='$PeopleID',Vehicle_ID='$VehicleID'";

  if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
 } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }

}

mysqli_close($conn);

?>



</main>
<div style="position:absolute; right:0;">
<a href="addcar.php">Back</a><br>
<a href="menu.php">Homepage</a><br>
<a href="login.php">Log out</a>
</div>
</body>
</html>