##got button from here https://cssbuttons.io/detail/alexroumi/shy-sloth-91##

<?php
// Start the session
session_start();
?>

<html>

<form action = "search.php">
<button> Search for person or car
</form> </button>
<form action ="addcar.php">
<button> Add new vehicle </br>
</button> </form>
<form action = "filereporthomepage.php">
<button> File/Edit a report 
</button>
</form>
<form action = "changepassword.php">
<button> Change password
</form> </button>
<form action = "login.php">
<button> Log out
</form> </button>


<?php
 if ($_SESSION['Admin'] == '1'){
   ?>
     <form action = "adduser.php">
<button> Create new user
</form> </button>
<?php
 }
 ?>

<style>
    body {
  height: 100px;
  background-color: white;
  background-image: url(https://pbs.twimg.com/profile_images/1410560774687313923/N8oxbEC0_400x400.jpg);
  background-repeat: repeat-y;
}
</style>
<style>


.text-center {
  text-align: center;
}


button {
    display: block;
    width: 500px;
}

button {
    padding: 20px 70px;
    border: unset;
    border-radius: 40px;
    color: #212121;
    z-index: 1;
    background: #e8e8e8;
    position: relative;
    font-weight: 1000;
    font-size: 20px;
    -webkit-box-shadow: 4px 8px 19px -3px rgba(0,0,0,0.27);
    box-shadow: 4px 8px 19px -3px rgba(0,0,0,0.27);
    transition: all 250ms;
    overflow: hidden;
    margin: auto;
    margin-top: 50px;
   }
   
   button::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    width: 0;
    border-radius: 15px;
    background-color: #212121;
    z-index: -1;
    -webkit-box-shadow: 4px 8px 19px -3px rgba(0,0,0,0.27);
    box-shadow: 4px 8px 19px -3px rgba(0,0,0,0.27);
    transition: all 250ms
   }
   
   button:hover {
    color: #e8e8e8;
   }
   
   button:hover::before {
    width: 100%;
   }


</style>
   </html>