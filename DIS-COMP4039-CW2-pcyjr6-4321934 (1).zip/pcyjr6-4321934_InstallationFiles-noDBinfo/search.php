<?php
// Start the session
session_start();
?>

<html>
<body>
<main>


  <h1>Look up Individual </h1>
  <h2><u>Enter one of the following fields</u></h2>

 
  <div>
  <form  method="post">
      Name: <input type="text" name="name" Required><br>
      <input type="submit" value="Search">
  </form>

  <form  method="post">
        Licence Number: <input type="text" name="licencenumber"><br/>
      <input type="submit" value="Search">
  </form>

  <form  method="post">
        Vehicle Licence Plate: <input type="text" name="vehiclelicenceplate"><br/>
      <input type="submit" value="Search">

  </form>
</div>

<style>
      div{margin-top: 50px;
      }

      html, body {
      display: flex;
      justify-content: center;
      font-family: Roboto, Arial, sans-serif;
      font-size: 18px;
      height: 100px;
      }
      input[type=text], input[type=name] {
      width: 100%;
      padding: 16px 8px;
      margin: 8px 0;
      display: inline-block;
      border: 1px solid #ccc;
      box-sizing: border-box;
      height: 50px;
      }
      input[type=submit] {
      background-color: blue;
      color: white;
      padding: 15px 0;
      margin: 5px 0;
      border: none;
      cursor: grabbing;
      width: 100%;
      }
      h1 {
      text-align:center;
      font-size:32;
      }
      h2 {
      text-align:center;
      font-size:20;
      }
      input:hover {
      opacity: 0.8;
      }
      .formcontainer {
      text-align: middle;
      margin: 24px 25px 20px;
      }
      .container {
      padding: 16px 0;
      text-align:left;
      }
      span.psw {
      float: right;
      padding-top: 100;
      padding-right: 30px;
      }

    </style>
  

<style>
    div.form
{
    display: block;
    text-align: center;
}
form
{
    display: inline-block;
    margin-left: auto;
    margin-right: auto;
    text-align: middle;
}

</style>

      <?php
        
        $user_check = $_SESSION['userid'];
       

        error_reporting(E_ALL);
        ini_set('display_errors',1);  

        // MySQL database information   
        $servername = "***";
        $username = "***";
        $password = "***";
        $dbname = "***"; 

        $conn = mysqli_connect($servername, $username, $password, $dbname);

        // Check whether variable is set
        if (isset($_POST['name']))
        {
        
          // Check connection
          $conn = mysqli_connect($servername, $username, $password, $dbname);
          if(!$conn) {
            die ("Connection failed");
            }
        // set variable  
        $name = $_POST['name'];

        // construct the SELECT query
        $sql = "SELECT * FROM People WHERE People_name LIKE \"%". $name. "%\"; ";
        // send query to DB
        $result = mysqli_query($conn, $sql);
        // check that something has been returned  
        if (mysqli_num_rows($result) > 0) {
            echo mysqli_num_rows($result)." records found:<br/>";

            // loop through each row of the result (each tuple will  
            // be contained in the associative array $row)
            while($row = mysqli_fetch_assoc($result))
            {
              // output name, address and licence
              echo $row["People_name"]." - ". $row["People_address"]." - ". $row["People_licence"]. "<br/>"; 
          }
      }
        
        else // if query result is empty
        {
          echo "Nothing found!";
        }
        mysqli_close($conn);
      }      

        // Check whether variable is set
        if (isset($_POST['licencenumber']))
        {
          // Check connection
          $conn = mysqli_connect($servername, $username, $password, $dbname);
          if(!$conn) {
            die ("Connection failed");
          } 
        // set variable  
        $licencenumber = $_POST['licencenumber'];
        // construct the SELECT query
        $sql = "SELECT * FROM People WHERE People_licence LIKE '$licencenumber'" ;
        // send query to DB
        $result = mysqli_query($conn, $sql);
        // check that something has been returned   
        if (mysqli_num_rows($result) > 0) {
            echo mysqli_num_rows($result)." records found<br/><br/>";

            // loop through each row of the result (each tuple will  
            // be contained in the associative array $row)            
            while($row = mysqli_fetch_assoc($result)) 
            {
              echo $row["People_name"]." - ". $row["People_address"]." - ". $row["People_licence"]. "<br/>"; 
          }
      }
      
      else // if query result is empty
      {
        echo "Nothing found!";
      }
          
        mysqli_close($conn);
    }
  
// Check whether variable is set
if (isset($_POST['vehiclelicenceplate']))
{
    // Check connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if (!$conn)
    {
        die("Connection failed");
    }
    // set variable
    $vehicleregplate = $_POST['vehiclelicenceplate'];
    //SQL statement. Need to have Vehicle licence plate, so this query accounts for missing data (People ID and People Name)
    $sql = "SELECT * FROM Vehicle Where Vehicle_licence = '$vehicleregplate' ";
    // send query to DB
    $result = mysqli_query($conn, $sql);
    // check that something has been returned
    if (mysqli_num_rows($result) > 0)
    {
        // loop through each row of the result (each tuple will
        // be contained in the associative array $row)
        while ($row = mysqli_fetch_assoc($result))
        {

            $Vehicle_colour = $row["Vehicle_colour"];
            $Vehicle_type = $row["Vehicle_type"];
            $Vehicle_licence = $row["Vehicle_licence"];

            if (!empty($Vehicle_type))
            {
                echo "<br>Vehicle Type: " . $Vehicle_type, "<br>";
            }
            else echo "<br>No Type found", "</br>"; //Error is missing info 

            if (!empty($Vehicle_colour))
            {
                echo "<br>Vehicle Colour: " . $Vehicle_colour, "<br>";
            }
            else echo "<br>No Colour found", "<br>";//Error is missing info 

            if (!empty($Vehicle_licence))
            {
                echo "<br>Vehicle REG: " . $Vehicle_licence, "<br>";
            }
            else echo "<br>No Car REG found", "<br>";//Error is missing info 
        }

        //This SQL statement then links tables, identifing links with People ID and Name to Vehicles to fill in the rest of the Information required
        $sql = "SELECT * FROM Vehicle, People, Ownership WHERE People.People_ID = Ownership.People_ID AND Vehicle.Vehicle_ID = Ownership.Vehicle_ID AND Vehicle_licence = '$vehicleregplate';";

        $result = mysqli_query($conn, $sql);
        // check that something has been returned
        if (mysqli_num_rows($result) > 0)
        {
            // loop through each row of the result (each tuple will
            // be contained in the associative array $row)
            while ($row = mysqli_fetch_assoc($result))
            {
                $People_name = $row["People_name"];
                $People_licence = $row["People_licence"];

                if (!empty($People_name))
                {
                    echo "<br>Person Name: " . $People_name, "<br>";
                }
                else echo "<br>No Owner name found", "<br>";//Error is missing info 

                if (!empty($People_licence))
                {
                    echo "<br>Person Licence number: " . $People_licence, "<br>";
                }
                else echo "<br>No Owner licence found", "<br>";//Error is missing info 

            }

        }
        if (mysqli_num_rows($result) == 0) //If nothing found, (missing PersonID in database, print error messages in place)
        {

            echo "<br>No Person Name found", "<br>";
            echo "<br>No Person Licence found", "<br>";
        }
    }

    else
    // if query result is empty
    
    {
        echo "Nothing found!<br>"; //If nothing matches database information, error message
    }
       
        mysqli_close($conn);
    } 

    ?>
     
</main>
<div1>
<footer><br><a href="menu.php">Back</a></footer>
<footer><a href="login.php">Log out</a></footer>
</div2>
</body>
</html>