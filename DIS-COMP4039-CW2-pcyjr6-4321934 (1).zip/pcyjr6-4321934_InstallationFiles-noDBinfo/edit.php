<?php
// Start the session
session_start();
?>
<html>
<body>

<?php

error_reporting(E_ALL);
ini_set('display_errors',1);
 
 $servername = "***";
        $username = "***";
        $password = "***";
        $dbname = "***"; 

$conn = mysqli_connect($servername, $username, $password, $dbname);
    // Check connection
    if(!$conn) {
    die ("Connection failed");
    }

$id = $_GET['id'];

$query = mysqli_query($conn,"SELECT Incident_date, Incident_time, Incident_report FROM Incident WHERE Incident_ID = '$id'");
// fetch data from database
while($row = mysqli_fetch_array($query))
{
    $olddate = $row['Incident_date']; 
    $oldtime = $row['Incident_time']; 
    $oldreport = $row['Incident_report']; 
}

if($_SESSION['Admin']== '1') :
$query = mysqli_query($conn,"SELECT Fine_Amount, Fine_Points FROM Fines WHERE Incident_ID = '$id'");
// fetch data from database
while($row = mysqli_fetch_array($query))
{
    $oldfineamount = $row['Fine_Amount']; 
    $oldfinepoints = $row['Fine_Points']; 
}
endif; 
mysqli_close($conn)


?>
<div>
<h1>Update Data</h1>


<form method="POST">
  Date: <input type = "date" name="date" Required><br/>
  Incident report:<input type="text" name="report" value="<?php echo $row['time'] ?>" placeholder="Incident Report" Required>
  Incident Time: <input type="time" name ="time"Required><br/>

  <?php if($_SESSION['Admin']== '1') : ?>
  Fine amount (£):<input type="text" name="amount" placeholder="New Fine Amount" >
  Fine points: <input type="text" name="points" placeholder="New Fine Points" >
  <?php endif; ?>

  <input type="submit" name="update" value="Update">

</form>
<style>

div{margin-top: 50px;
    }

    html, body {
    display: flex;
    justify-content: center;
    font-family: Roboto, Arial, sans-serif;
    font-size: 15px;
    height: 100px;
    }
    form {
    border: 0px solid #f1f1f1;
    }
    input[type=text], input[type=date], input[type=time] {
    width: 100%;
    padding: 16px 8px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
    height: 50px;
    }
    input[type=submit] {
    background-color: blue;
    color: white;
    padding: 14px 0;
    margin: 10px 0;
    border: none;
    cursor: grabbing;
    width: 100%;
    }
    h1 {
    text-align:center;
    font-size:32;
    }
    button:hover {
    opacity: 0.8;
    }
    .formcontainer {
    text-align: left;
    margin: 24px 50px 20px;
    }
    .container {
    padding: 16px 0;
    text-align:left;
    }
    span.psw {
    float: right;
    padding-top: 100;
    padding-right: 30px;
    }

  </style> 


<?php

$servername = "mysql.cs.nott.ac.uk";
$username = "pcyjr6";
$password = "Purple937415!";
$dbname = "pcyjr6";   

$conn = mysqli_connect($servername, $username, $password, $dbname);
    // Check connection
    if(!$conn) {
    die ("Connection failed");
    }

$id = $_GET['id']; // get id through query string

$query = mysqli_query($conn,"select * from Incident where Incident_ID='$id'"); // select query
$row = mysqli_fetch_array($query); // fetch data

if(isset($_POST['update'])) // when you click on the Update button
{
  $incidentdate = $_POST['date'];
  $time = $_POST['time'];
  $report = $_POST['report']; 

  $amount = $_POST['amount']; 
  $points = $_POST['points']; 
  
  $sql = "UPDATE Incident SET Incident_Report='$report', Incident_Time ='$time', Incident_Date = '$incidentdate' where Incident_ID='$id'";
  $conn->query($sql);


 
  if($_SESSION['Admin']== '1') :
    $sql = "UPDATE Fines SET Fine_Amount='$amount', Fine_Points ='$points' where Incident_ID='$id'";
    $conn->query($sql);
    endif; 


     mysqli_close($conn); // Close connection
     header("location:showreport.php"); // redirects to all records page
     exit;
    }

?>

</main>
</body>
<div2 style="position:fixed; right:5; top:5; font-family: Roboto, Arial, sans-serif;
      font-size: 20px;">
<footer><a href="showreport.php">Back</a></footer>
<footer><a href="menu.php">Homepage</a></footer>
<footer><a href="login.php">Log out</a></footer>
  </div2>
</html>



