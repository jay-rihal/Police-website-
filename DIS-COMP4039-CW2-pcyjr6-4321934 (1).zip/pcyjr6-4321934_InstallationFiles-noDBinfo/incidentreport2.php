<?php
// Start the session

session_start();
?>
<html>
<body>
  <div>

<h1> File a new report </h1>

<form method="POST">
  Date: <input type = "date" name="date" Required><br/>

  Time: <input type="time" name ="time"Required><br/>

  Vehicle REG: <input type="text" name="vehicleREG" placeholder="Vehicle REG" Required> 
  <br/>

  Vehicle Make and model: <input type="text" name="vehiclemake" placeholder="Vehicle make and model"> 
  <br/>

  Vehicle Colour: <input type="text" name="vehiclecolour" placeholder="Vehicle colour"> 
  <br/>

  Person Name: <input type="text" name="personname" placeholder="Person name" Required>
  <br/>

  Person Address: <input type="text" name="personaddress" placeholder="Person address">
  <br/>

  Person Licence: <input type="text" name="personlicence" placeholder="Individual Licence Number" Required>
  <br/>

  <p>Please enter a textual statement of the incident below</p>
  
      <textarea name="statement" rows="10" cols="30"></textarea><br/>

      <br><label for ="Fines"> Choose a Fine:</label>
      <select id="Fine" name ="offencedescription">
      <option value = "Null" >-----select an option----</option>
      <option value = "Speeding" >Speeding</option>
      <option value = "Speeing on the motorway" >Speeing on the motorway</option>
      <option value = "Seat belt offence" >Seat belt offence</option>
      <option value = "Illegal parking" >Illegal parking</option>
      <option value = "Drink driving" >Drink driving</option>
      <option value = "Driving without a licence" >Driving without a licence</option>
      <option value = "Traffic light offences" >Traffic light offences</option>
      <option value = "Cycling on pavement" >Cycling on pavement</option>
      <option value = "Failure to have control of vehicle" >Failure to have control of vehicle</option>
      <option value = "Dangerous driving" >Dangerous driving</option>
      <option value = "Careless driving" >Careless driving</option>
      <option value = "Dangerous cycling" >Dangerous cycling</option><br>

  <input type="submit" name="submit" value="Submit">
</form>
</div>

<style>

  div{margin-top: 10px;
    justify-content: center;
      }

      html, body {
      display: flex;
      justify-content: center;
      font-family: Roboto, Arial, sans-serif;
      font-size: 15px;
      height: 100px;
      }
      form {
      border: 0px solid #f1f1f1;
      }
      input[type=text] {
      width: 100%;
      padding: 16px 8px;
      margin: 8px 0;
      display: inline-block;
      border: 1px solid #ccc;
      box-sizing: border-box;
      height: 25px;
      }
      input[type=time], input[type=date] {
      background-color: white;
      color: black;
      padding: 14px 0;
      margin: 10px 0;
      border: none;
      cursor: grabbing;
      width: 100%;
      margin-top: 10px;
      }
      input[type=submit]{
      background-color: blue;
      color: white;
      padding: 14px 0;
      margin: 10px 0;
      border: none;
      cursor: grabbing;
      width: 100%;
      margin-top: 10px;
      }
      h1 {
      text-align:center;
      font-size:32;
      }
      button:hover {
      opacity: 0.8;
      }
      .formcontainer {
      text-align: left;
      margin: 24px 50px 20px;
      }
      .container {
      padding: 16px 0;
      text-align:left;
      }
      span.psw {
      float: right;
      padding-top: 100;
      padding-right: 30px;
      }

    </style> 

<?php


$user_check = $_SESSION['userid'];

error_reporting(E_ALL);
ini_set('display_errors',1);  

// MySQL database information   
 $servername = "***";
        $username = "***";
        $password = "***";
        $dbname = "***";    

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (isset($_POST['vehicleREG'])) //what if they dont know time? Write ("put x") on website
{
    $date = $_POST['date'];
    $time = $_POST['time'];
    $vehicleREG = $_POST['vehicleREG'];// check for the vehicle
    $vehiclemake = $_POST['vehiclemake'];
    $vehiclecolour = $_POST['vehiclecolour'];
    $personname = $_POST['personname'];
    $personaddress = $_POST['personaddress'];
    $personlicence = $_POST['personlicence'];// checks for the person
    $statement = $_POST['statement'];
    $offencename = $_POST['offencedescription']; 

    $sql = "INSERT INTO Vehicle SET Vehicle_type='$vehiclemake', Vehicle_colour='$vehiclecolour',Vehicle_licence='$vehicleREG'";   
    if ($conn->query($sql) === TRUE) {
        echo "";
      } 
      else 
      {
        echo "Error: " . $sql . "<br>" . $conn->error;
      }

$sql = "SELECT * FROM Vehicle WHERE Vehicle_licence ='$vehicleREG'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) == 0)
{
        echo "Vehicle not found! - added to database", "<br>";
        $sql = "INSERT INTO Vehicle SET Vehicle_licence='$vehicleREG'";
        if ($conn->query($sql) === TRUE) {
            echo "";
          } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
          }
}

$sql = "SELECT * from Vehicle WHERE Vehicle_licence ='$vehicleREG'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0)
{
    while ($row = mysqli_fetch_assoc($result))
    {
       $vehicleID=$row['Vehicle_ID'];
    }
}

$sql = "SELECT * FROM Vehicle WHERE Vehicle_type ='$vehiclemake'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) == 0)
{
        $sql = "INSERT INTO Vehicle SET Vehicle_type='$vehiclemake'";
        if ($conn->query($sql) === TRUE) {
            echo "";
          } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
          }
}

$sql = "SELECT * from Vehicle WHERE Vehicle_colour ='$vehiclecolour'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0)
{
    while ($row = mysqli_fetch_assoc($result))
    {
       $vehicleID=$row['Vehicle_ID'];
    }
}

$sql = "SELECT * FROM Vehicle WHERE Vehicle_colour ='$vehiclecolour'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) == 0)
{
        $sql = "INSERT INTO Vehicle SET Vehicle_colour='$vehiclecolour'";
        if ($conn->query($sql) === TRUE) {
            echo "";
          } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
          }
}

$sql = "SELECT * from Vehicle WHERE Vehicle_colour ='$vehiclecolour'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0)
{
    while ($row = mysqli_fetch_assoc($result))
    {
       $vehicleID=$row['Vehicle_ID'];
    }
}

$sql = "INSERT INTO People SET People_name='$personname', People_address='$personaddress',People_licence='$personlicence'";
        
if ($conn->query($sql) === TRUE) {
    echo "";
  } 
  else 
  {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }

$sql = "SELECT * FROM People WHERE People_name = '$personname'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) == 0)
{
    echo "Person not found! so adding to database", "<br>";
    $sql = "INSERT INTO People SET People_name ='$personname'";
    if ($conn->query($sql) === TRUE) {
        echo "";
      } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
      }
}

$sql = "SELECT * from People WHERE People_name ='$personname'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0)
{
    while ($row = mysqli_fetch_assoc($result))
    {
       $peopleID=$row['People_ID'];
    }
}


$sql = "SELECT * FROM People WHERE People_address = '$personaddress'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) == 0)
{
    echo "Person Address not found! so adding to database", "<br>";
    $sql = "INSERT INTO People SET People_address ='$personaddress'";
    if ($conn->query($sql) === TRUE) {
        echo "";
      } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
      }
}

$sql = "SELECT * from People WHERE People_address ='$personaddress'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0)
{
    while ($row = mysqli_fetch_assoc($result))
    {
       $peopleID=$row['People_ID'];
    }
}



$sql = "SELECT * FROM People WHERE People_licence = '$personlicence'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) == 0)
{
    echo "Person licence not found! so adding to database", "<br>";
    $sql = "INSERT INTO People SET People_licence ='$personlicence'";
    if ($conn->query($sql) === TRUE) {
        echo "";
      } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
      }
}

$sql = "SELECT * from People WHERE People_licence ='$personlicence'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0)
{
    while ($row = mysqli_fetch_assoc($result))
    {
       $peopleID=$row['People_ID'];
    }
}


$sql = "INSERT into Ownership SET People_ID='$peopleID',Vehicle_ID='$vehicleID'";

if ($conn->query($sql) === TRUE) 
{
    echo "Report created successfully";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }


$sql = "SELECT * FROM Offence WHERE Offence_Description = '$offencename'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0)
{
     while($row = mysqli_fetch_assoc($result)) 
     {
       $offenceid = $row["Offence_ID"];
    }
}


$sql = "INSERT INTO Incident SET Vehicle_ID='$vehicleID',People_ID='$peopleID', Incident_Date='$date', Incident_Time = '$time', Incident_Report='$statement', Offence_ID = '$offenceid' ";
  
  if ($conn->query($sql) === TRUE) {
      echo "!";
    } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $sql = "SELECT * FROM Incident WHERE Vehicle_ID='$vehicleID' and People_ID='$peopleID' and Incident_Date='$date' and Incident_Time = '$time' and Incident_Report='$statement' and Offence_ID = '$offenceid' ";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0)
    {
    while($row = mysqli_fetch_assoc($result))
    {
    $incidentID = $row["Incident_ID"];}
    }
    
    $sql = "INSERT INTO Fines SET Fine_Amount='0',Fine_Points='0', Incident_ID = '$incidentID'";
    $conn->query($sql);

}



mysqli_close($conn);

?>


</main>
<div style="position:absolute; right:0;">
<footer><a href="filereporthomepage.php">Back</a></footer>
<footer><a href="page000.php">Log out</a></footer>
</body>
</html>