<?php
// Start the session
session_start();
?>

<!DOCTYPE html>
<html>
<head>
  <title>Display all records from Database</title>
</head>


<h2>Existing reports</h2>
<body>
<table border="2">
  <tr>
    <td>IncidentID</td>
    <td>Person Name</td>
    <td>Person Drivers Licence</td>
    <td>Person Address</td>
    <td>Vehicle Type</td>
    <td>vehicle Colour</td>
    <td>Vehicle REG</td>
    <td>Incident Date</td>
    <td>Incident Time</td>
    <td>Incident Report</td>
    <td>Fine Amount</td>
    <td>Fine Points</td>
    <td>Edit</td>
    <?php if($_SESSION['Admin']== '1') :?>
      <td>Delete</td>
    <?php endif;?>
    
  </tr>
  <style>
  h2 {
      text-align:center;
      font-size:32px;
      line-height: 100px;
      margin-top: -90px;
      white-space: nowrap;
      }
      </style>
<style>
  html, body {
    text-align: left;
      
      justify-content: center;
      font-family: Roboto, Arial, sans-serif;
      font-size: 15px;
      height: 150px;
      margin-top: 50px;
      }

  </style>

<?php

error_reporting(E_ALL);
ini_set('display_errors',1);  
// MySQL database information   

 $servername = "***";
        $username = "***";
        $password = "***";
        $dbname = "***";   

$conn = mysqli_connect($servername, $username, $password, $dbname);
    // Check connection
    if(!$conn) {
    die ("Connection failed");
    }

    //used a join to only show records once with no repeats
$records = mysqli_query($conn,
"SELECT Incident.Incident_ID, Incident.Incident_date, Incident.Incident_time, Incident.Incident_report,People.People_name,People.People_address,People.People_licence, Vehicle.Vehicle_type, Vehicle.Vehicle_colour,Vehicle.Vehicle_licence,Fines.Fine_Amount, Fines.Fine_Points 
FROM Incident
left JOIN Fines ON Fines.Incident_ID = Incident.Incident_ID
left JOIN Vehicle on Vehicle.Vehicle_ID = Incident.Vehicle_ID 
left JOIN People on People.People_ID = Incident.People_ID
");

while($row = mysqli_fetch_array($records))

{

?>
  <tr>
    
    <td><?php echo $row['Incident_ID']; ?></td>
    <td><?php echo $row['People_name']; ?></td>
    <td><?php echo $row['People_licence']; ?></td>
    <td><?php echo $row['People_address']; ?></td>
    <td><?php echo $row['Vehicle_type']; ?></td>
    <td><?php echo $row['Vehicle_colour']; ?></td>
    <td><?php echo $row['Vehicle_licence']; ?></td>
    <td><?php echo $row['Incident_date']; ?></td>
    <td><?php echo $row['Incident_time']; ?></td>   
    <td><?php echo $row['Incident_report']; ?></td>
    <td><?php echo $row['Fine_Amount']; ?></td>
    <td><?php echo $row['Fine_Points']; ?></td>    
 
    <td><a href="edit.php?id=<?php echo $row['Incident_ID'];?>">Edit</a></td>
    <?php if($_SESSION['Admin']== '1') :?>
    <td><a href="delete.php?id=<?php echo $row['Incident_ID'];?>">Delete</a></td>
    <?php endif;?>

  </tr>	
<?php
}
?>
</table>



</main>
</body>
<div2 style="position:fixed; right:5; top:5; font-family: Roboto, Arial, sans-serif;
      font-size: 20px;">
<footer><a href="filereporthomepage.php">Back</a></footer>
<footer><a href="menu.php">Homepage</a></footer>
<footer><a href="login.php">Log out</a></footer>
</div2>
</html>